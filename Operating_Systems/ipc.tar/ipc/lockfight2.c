#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

int create_lockfile(char*,int);

void handle_file_status(int, char*,int);

int main() {
  int file_status;
  int i;
  char* filename = "/usr/tmp/lockfight_lockfile";

  int pid;

  pid = getpid();

  for (i = 0; i < 5; i++) {
    file_status = create_lockfile(filename,pid);
    
    handle_file_status(file_status,filename,pid);

  }
}


int create_lockfile(char *filename,int pid) {
  int fd;

  printf("Process %d ",pid);

  fd = open(filename, O_EXCL | O_CREAT);

  close(fd);
  if (fd > 0) {
    printf("successfully locks the lock\n");
  }

  else {
    printf("finds lock locked\n");
  }
  return fd;
}


void handle_file_status(int file_status, char *filename,int pid) {
  // If File exists
  printf("Process %d ",pid);
  if (file_status < 0) {
    printf("Waiting for 3 seconds.\n");
    sleep(3);
  }

  else {

    int rando; 
    rando = rand() % 10;
    printf("Holding lock for %d seconds.\n",rando);
    sleep(rando);
    unlink(filename);
  }

}
