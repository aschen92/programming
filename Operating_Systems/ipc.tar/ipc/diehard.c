/**
 * Brett Peterson
 * Program 1: Diehard
*/

#include <stdio.h>
#include <signal.h>

void sigHandler(int);

int main() {
  int x = 0;

  printf("I'm a tough process, you can't kill me!\n");

  // Unnecessary amount of signal handlers
  signal(NSIG,sigHandler);
  signal(SIGABRT,sigHandler);
  signal(SIGALRM,sigHandler);
  signal(SIGBUS, sigHandler);
  signal(SIGCHLD, sigHandler);
  signal(SIGCLD,sigHandler);
  signal(SIGCONT,sigHandler);
  signal(SIGFPE,sigHandler);
  signal(SIGHUP,sigHandler);
  signal(SIGILL,sigHandler);
  signal(SIGINT,sigHandler);
  signal(SIGIO,sigHandler);
  signal(SIGIOT,sigHandler);
  signal(SIGKILL,sigHandler);
  signal(SIGPIPE,sigHandler);
  signal(SIGPOLL,sigHandler);
  signal(SIGPROF,sigHandler);
  signal(SIGPWR,sigHandler);
  signal(SIGQUIT,sigHandler);
  signal(SIGRTMAX,sigHandler);
  signal(SIGRTMIN,sigHandler);
  signal(SIGSEGV,sigHandler);
  signal(SIGSTOP,sigHandler);
  signal(SIGSYS,sigHandler);
  signal(SIGTERM,sigHandler);
  signal(SIGTRAP,sigHandler);
  signal(SIGTSTP,sigHandler);
  signal(SIGTTIN,sigHandler);
  signal(SIGTTOU,sigHandler);
  signal(SIGURG,sigHandler);
  signal(SIGUSR1,sigHandler);
  signal(SIGUSR2,sigHandler);
  signal(SIGVTALRM,sigHandler);
  signal(SIGWINCH,sigHandler);
  signal(SIGXCPU,sigHandler);
  signal(SIGXFSZ,sigHandler);
  signal(SIGTERM,sigHandler);
  signal(SIG_SETMASK,sigHandler);

  while(x < 6) {
    // Pause waiting for signal
    pause();
    
    printf("Hit number: %d\n", x);
    x += 1;
  }
  exit(1);
}

/**
   This is the signal handler. It just prints out
   what signal it received.
 **/
  
void sigHandler (int sig) {
  printf("Received Signal: %d\n", sig);
}
