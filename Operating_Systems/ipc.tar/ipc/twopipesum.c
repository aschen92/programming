#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[]) 
{
  int pipefd[2];

  int val_a;
  int val_b;

  pid_t parent_id;
  
  if (pipe(pipefd) == -1){
    perror("pipe a");
    exit(EXIT_FAILURE);
  }
  
  
  if (pipe(pipefd) == -1) {
    perror("pipe b");
    exit(EXIT_FAILURE);
  }
  
  if (fork() != 0) {


    wait();

    close(pipefd[1]);

    read(pipefd[0], &val_a, sizeof(val_a));
    read(pipefd[0], &val_b, sizeof(val_b));
    
    printf("%d + %d = %d\n", val_a, val_b, val_a + val_b);
  } 
  else {
    int rand_val;
    if (fork() != 0) {
      close(pipefd[0]);
      parent_id = getppid();
      srand(parent_id);
      rand_val = rand() % 100;
      
      write(pipefd[1], &rand_val, sizeof(rand_val));

      close(pipefd[1]);
      exit(0);
    }

    close(pipefd[0]);

    parent_id = getppid();
    srand(parent_id);
    
    rand_val = rand() % 100;

    write(pipefd[1], &rand_val, sizeof(rand_val));

    close(pipefd[1]);

    exit(0);
  }
  
  return 0;
}
