/**
   Brett Peterson
   Aaron Schendel
   
   Lockfight
 */

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

pthread_mutex_t lock;

void *threadFunc(int);

int main(int argc, char *argv[]) {
  int thread_count;
  int i,j;

  // Handle input
  
  if (argc != 2) {
    fprintf(stderr, "input must have integer value\n");
    return -1;
  }
  
  if (atoi(argv[1]) < 0) {
    fprintf(stderr, "%d must be >= 0\n", atoi(argv[1]));
    return -1;
  }
    
  thread_count = atoi(argv[1]);


  pthread_t tid[thread_count];
  pthread_attr_t attr[thread_count];
  for (i = 0; i < 5; i++) {
    for (j = 0; j < thread_count; j++) {
      
      pthread_attr_init(&attr[j]);
      pthread_create(&tid[j], &attr[j], threadFunc, j);

    }
  }
  

  for (i = 0; i < thread_count; i++) {
    pthread_join(tid[i], NULL);
  }
  return 0;
}

void *threadFunc(thread) {
  pthread_mutex_lock(&lock);

  int rando;

  rando = rand() % 5;
  
  //output
  printf("Thread %d got lock.\n",thread);
  printf("Thraad %d holding lock for %d seconds\n",thread, rando);
  
  sleep(rando);

  printf("Thread %d releasing lock.\n\n",thread);

  pthread_mutex_unlock(&lock);
  pthread_exit(0);
}
