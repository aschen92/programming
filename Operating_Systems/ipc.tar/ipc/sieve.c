#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void sift();

int main(int argc, char *argv[]) {
  int pipefd[2];
  int i;
  pid_t cpid;

  pipe(pipefd);
  close(pipefd[0]);

  write(pipefd[1],&i, sizeof(int));
  close(pipefd[1]);

  for (i = 0; i < 10; i++) {
    sift(pipefd);
    wait();
  }

}

void sift(int *pipe) {
  pid_t pid = fork();
  int test;

  close(pipe[1]);
  if (pid != 0) {
    read(pipe[0],&test,sizeof(int));
    printf("[%d]: %d \n",pid,test);
    close(pipe[0]);
  }
  else
    exit(0);
}
