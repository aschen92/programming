:- [mvw_sim, random_agt].

:- random_env(E), run_agent(E,1).
